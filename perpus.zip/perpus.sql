-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Nov 2020 pada 15.30
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id` double NOT NULL,
  `kode` varchar(200) NOT NULL DEFAULT '',
  `gambar` blob NOT NULL DEFAULT '',
  `judul` varchar(200) DEFAULT NULL,
  `pengarang` varchar(200) DEFAULT NULL,
  `penerbit` varchar(200) DEFAULT NULL,
  `tahun` int(100) DEFAULT NULL,
  `isbn` varchar(40) DEFAULT NULL,
  `stok` int(200) DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `tgl` text DEFAULT NULL,
  `kotaterbit` varchar(100) DEFAULT NULL,
  `klasifikasi` varchar(100) DEFAULT NULL,
  `subklasifikasi` varchar(100) DEFAULT NULL,
  `deskripsi` varchar(300) DEFAULT NULL,
  `sumber` varchar(100) DEFAULT NULL,
  `sinopsis` char(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id`, `kode`, `gambar`, `judul`, `pengarang`, `penerbit`, `tahun`, `isbn`, `stok`, `lokasi`, `tgl`, `kotaterbit`, `klasifikasi`, `subklasifikasi`, `deskripsi`, `sumber`, `sinopsis`) VALUES
(1, 'AH9', 0x617261682d6c616e676b61682e6a7067, 'Arah langkah', 'Fiersa', 'Media', 2018, '342434343', 3, 'Rak B', '2020-01-13', 'jakarta', 'novel', 'fiksi', 'baru', 'beli', 'Arah langkah adalah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` double NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1922020003, 'admin', 'admin', '$2y$10$fHt9I2Uvz2cCcxF4wNXLF.0Vu2m9sLij4BrRseXHKuUi.uqyWDv9O', 'admin'),
(1922020011, 'Ar Rasyid Yudha Pradana', 'rasyid', '$2y$10$OLakC/EkJyje3O8ZFzlI7OU8y8ZVI4ERrNQU7y17uZomq/0hw8Kdq', 'user');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id` int(50) UNSIGNED DEFAULT NULL,
  `kodebuku` varchar(100) DEFAULT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `username` varchar(200) NOT NULL,
  `judul` varchar(200) DEFAULT NULL,
  `pinjam` varchar(10) DEFAULT NULL,
  `kembali` varchar(10) DEFAULT NULL,
  `kodepinjam` int(11) NOT NULL,
  `status` text NOT NULL DEFAULT 'Sedang di proses'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id` double NOT NULL,
  `kodebuku` varchar(45) DEFAULT NULL,
  `nama` varchar(145) DEFAULT NULL,
  `username` varchar(145) DEFAULT NULL,
  `judul` varchar(145) DEFAULT NULL,
  `pinjam` text DEFAULT NULL,
  `kembali` text DEFAULT NULL,
  `kodepinjam` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `riwayat`
--

INSERT INTO `riwayat` (`id`, `kodebuku`, `nama`, `username`, `judul`, `pinjam`, `kembali`, `kodepinjam`) VALUES
(1922020009, 'FF4343', 'member', 'member', 'Arah Langkah', '2020-02-25', '2020-02-26', '2002210006'),
(1922020004, 'FF4343', 'coba1', 'coba', 'Arah Langkah', '2020-02-24', '2020-02-25', '2002210023'),
(1922020001, 'FF4343', 'dodit setyawan', 'dodit', 'Arah Langkah', '2020-02-25', '2020-02-27', '2002210024'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-28', '2020-08-29', '2002210025'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-28', '2020-08-29', '2002210026'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-28', '2020-08-30', '2002210027'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-06', '2020-08-07', '2002210028'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-12', '2020-08-13', '2002210029'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-27', '2020-08-28', '2002210030'),
(1922020011, 'AH9', 'Ar Rasyid Yudha Pradana', 'rasyid', 'Arah langkah', '2020-08-28', '2020-08-29', '2002210032');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`kodepinjam`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`kodepinjam`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1922020012;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `kodepinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2002210033;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
